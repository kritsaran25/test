<?php 

session_start();

require_once 'connect_db.php';

// echo $_SESSION['userId'];

// if(!$_SESSION['STAFF_ID']) {
// 	// header('location: http://localhost/OnlineRequestFormOpeningCourse/login.php');	
// }



?>