<?php 
require_once 'php_action/core.php';
require_once 'includes/header.php'; ?>
<div class="text">staff coc</div>
  <div class="content">
    <?php echo $U_TYPE ;?>
  <!-- content -->
  </div>
<?php require_once 'includes/footer.php'; ?>